
import io
from PIL import Image

def annotate_photo(buf, annotations, output_format="PNG"):
    """旧形式のアノテーション（スタブ：何もせずに返す）"""
    img = Image.open(buf)
    out = io.BytesIO()
    img.save(out, format=output_format)
    out.seek(0)
    return out

def annotate_photo_with_markers(buf, markers, output_format="PNG"):
    """新形式（写真ファースト）のマーカー焼き込み（スタブ：何もせずに返す）"""
    img = Image.open(buf)
    out = io.BytesIO()
    img.save(out, format=output_format)
    out.seek(0)
    return out
